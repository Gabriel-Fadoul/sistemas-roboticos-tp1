#!/usr/bin/env python3
"""Gráficos e métricas do ensaio `goto` (Relatório 5).

Uso:
  python3 plot_goto.py goto_cfg1.csv goto_cfg2.csv goto_cfg3.csv \
      --labels "cfg 1 (k_alpha = 2, k_rho = 1)" "cfg 2 (k_alpha = 4)" "cfg 3 (k_alpha = 4, k_rho = 10)"

Lê CSVs com colunas t, x, y, yaw, gx, gy, goal_idx, rho, alpha, v, w (linhas '#'
são ignoradas), corta cada ensaio em t <= --tmax (padrão 180 s) e gera, em --outdir:
  trajetoria_goto.(png|pdf)         trajetória com as metas atingidas
  rho_alpha_goto.(png|pdf)          rho e alpha x tempo (ensaio inteiro)
  rho_alpha_zoom_goto.(png|pdf)     o mesmo nos primeiros --zoom segundos
  metricas_goto.csv                 tabela de métricas (também impressa)
  trechos_goto.csv                  um trecho (meta) por linha, de todas as configurações

Definições:
  trecho k = intervalo em que goal_idx == k. Ele começa quando a meta k aparece
  (t = 0 para a primeira, partindo da pose inicial) e termina quando a meta k+1 aparece,
  ou seja, quando o simulador considera a meta k atingida.
  Meta atingida = trecho completo dentro de t <= tmax; o trecho em curso no fim não conta.
  d = distância em linha reta da pose no início do trecho até a meta.
  Velocidade média efetiva = soma(d) / soma(tempo): normaliza o fato de cada ensaio
  sortear metas diferentes (mais ou menos distantes).
  Eficiência = ((d - 0,06) / V_MAX) / tempo, ou seja, o tempo mínimo teórico a V_MAX
  dividido pelo tempo real (1,0 = ideal).
"""
import argparse
import math
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

ARENA_HALF = 1.0     # paredes em +-1,0 m
GOAL_HALF = 0.75     # metas sorteadas em +-0,75 m
GOAL_RADIUS = 0.06   # raio de captura do simulador
V_MAX = 0.2


def load(path, tmax):
    d = pd.read_csv(path, comment="#")
    return d[d["t"] <= tmax].reset_index(drop=True)


def trechos(d):
    """Um dicionário por trecho (meta) do ensaio; 'completo' = a meta foi atingida."""
    rows = []
    idxs = sorted(d["goal_idx"].unique())
    for k in idxs:
        sub = d[d["goal_idx"] == k]
        nxt = d[d["goal_idx"] == k + 1]
        t0 = sub["t"].iloc[0]
        x0, y0 = sub["x"].iloc[0], sub["y"].iloc[0]
        gx, gy = sub["gx"].iloc[0], sub["gy"].iloc[0]
        complete = len(nxt) > 0
        dur = (nxt["t"].iloc[0] - t0) if complete else math.nan
        dist = math.hypot(gx - x0, gy - y0)
        rows.append({
            "goal_idx": int(k), "t_inicio": t0, "duracao": dur, "completo": complete,
            "gx": gx, "gy": gy, "x0": x0, "y0": y0, "d_reta": dist,
            "rho_final": sub["rho"].iloc[-1] if complete else math.nan,
            "eficiencia": ((max(dist - GOAL_RADIUS, 0.0) / V_MAX) / dur) if complete else math.nan,
        })
    return pd.DataFrame(rows)


def bootstrap_ci(values_fn, n, reps=5000, seed=0):
    """IC95% por bootstrap sobre os trechos; values_fn recebe índices reamostrados."""
    rng = np.random.default_rng(seed)
    stats = [values_fn(rng.integers(0, n, n)) for _ in range(reps)]
    return np.percentile(stats, [2.5, 97.5])


def metrics(tr):
    c = tr[tr["completo"]].reset_index(drop=True)
    n = len(c)
    t, dist = c["duracao"].to_numpy(), c["d_reta"].to_numpy()
    out = {"metas atingidas": n}
    if n == 0:
        return out
    ci_t = bootstrap_ci(lambda i: t[i].mean(), n)
    ci_v = bootstrap_ci(lambda i: dist[i].sum() / t[i].sum(), n)
    out.update({
        "tempo médio por meta (s)": t.mean(),
        "  IC95% inferior (s)": ci_t[0],
        "  IC95% superior (s)": ci_t[1],
        "desvio padrão do tempo (s)": t.std(ddof=1) if n > 1 else math.nan,
        "mediana do tempo (s)": np.median(t),
        "pior trecho (s)": t.max(),
        "distância média em linha reta (m)": dist.mean(),
        "velocidade média efetiva (m/s)": dist.sum() / t.sum(),
        "  IC95% inferior (m/s)": ci_v[0],
        "  IC95% superior (m/s)": ci_v[1],
        "eficiência média (1 = ideal)": c["eficiencia"].mean(),
        "rho final máximo (m)": c["rho_final"].max(),
    })
    return out


def plot_trajectories(data, trs, labels, outdir):
    n = len(data)
    fig, axes = plt.subplots(1, n, figsize=(4.8 * n, 5.2), squeeze=False)
    for ax, d, tr, lab in zip(axes[0], data, trs, labels):
        ax.add_patch(Rectangle((-ARENA_HALF, -ARENA_HALF), 2 * ARENA_HALF, 2 * ARENA_HALF,
                               fill=False, edgecolor="0.25", linewidth=2.5))
        ax.add_patch(Rectangle((-GOAL_HALF, -GOAL_HALF), 2 * GOAL_HALF, 2 * GOAL_HALF,
                               fill=False, edgecolor="0.6", linewidth=0.8, linestyle=":"))
        ax.plot(d["x"], d["y"], color="#1f4e9c", linewidth=0.6, alpha=0.8, zorder=2)
        done = tr[tr["completo"]]
        pend = tr[~tr["completo"]]
        ax.plot(done["gx"], done["gy"], "o", color="#2e9e4f", markersize=5,
                markeredgecolor="white", markeredgewidth=0.5, zorder=4,
                label="metas atingidas (%d)" % len(done))
        if len(pend):
            ax.plot(pend["gx"], pend["gy"], "o", markerfacecolor="none", markeredgecolor="red",
                    markersize=7, zorder=4, label="meta em curso")
        ax.plot(d["x"].iloc[0], d["y"].iloc[0], "s", color="black", markersize=6, zorder=5,
                label="início")
        ax.set_xlim(-ARENA_HALF - 0.05, ARENA_HALF + 0.05)
        ax.set_ylim(-ARENA_HALF - 0.05, ARENA_HALF + 0.05)
        ax.set_aspect("equal")
        ax.set_xlabel("x (m)")
        ax.set_title(lab, fontsize=9)
        ax.grid(alpha=0.25)
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), fontsize=8, ncol=3, frameon=False)
    axes[0][0].set_ylabel("y (m)")
    fig.tight_layout()
    save(fig, outdir, "trajetoria_goto")


def plot_rho_alpha(data, trs, labels, outdir, name, tlim=None):
    n = len(data)
    fig, axes = plt.subplots(2, n, figsize=(5.2 * n, 5.6), sharex=True, sharey="row", squeeze=False)
    for j, (d, tr, lab) in enumerate(zip(data, trs, labels)):
        dd = d if tlim is None else d[d["t"] <= tlim]
        ax_r, ax_a = axes[0][j], axes[1][j]
        ax_r.plot(dd["t"], dd["rho"], color="#1f4e9c", linewidth=0.8)
        ax_a.plot(dd["t"], dd["alpha"], color="#c0392b", linewidth=0.8)
        if tlim is not None:  # no zoom, marca as trocas de meta
            for t0 in tr["t_inicio"].iloc[1:]:
                if t0 <= tlim:
                    for ax in (ax_r, ax_a):
                        ax.axvline(t0, color="0.7", linewidth=0.6, linestyle=":")
        ax_r.set_title(lab, fontsize=9)
        ax_r.grid(alpha=0.25)
        ax_a.grid(alpha=0.25)
        ax_a.set_xlabel("tempo (s)")
        ax_a.set_ylim(-math.pi - 0.2, math.pi + 0.2)
        ax_a.set_yticks([-math.pi, -math.pi / 2, 0, math.pi / 2, math.pi])
        ax_a.set_yticklabels(["−π", "−π/2", "0", "π/2", "π"])
    axes[0][0].set_ylabel("ρ (m)")
    axes[1][0].set_ylabel("α (rad)")
    fig.tight_layout()
    save(fig, outdir, name)


def save(fig, outdir, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(outdir, "%s.%s" % (name, ext)), dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("csvs", nargs="+", help="um CSV por configuração")
    ap.add_argument("--labels", nargs="+", help="um rótulo por CSV (padrão: nome do arquivo)")
    ap.add_argument("--tmax", type=float, default=180.0, help="corte em segundos (padrão 180)")
    ap.add_argument("--zoom", type=float, default=30.0, help="janela do gráfico ampliado (s)")
    ap.add_argument("--outdir", default="figuras")
    args = ap.parse_args()

    labels = args.labels or [os.path.splitext(os.path.basename(p))[0] for p in args.csvs]
    if len(labels) != len(args.csvs):
        ap.error("--labels precisa ter o mesmo número de itens que os CSVs")
    os.makedirs(args.outdir, exist_ok=True)

    data = [load(p, args.tmax) for p in args.csvs]
    trs = [trechos(d) for d in data]

    # Verificação: na troca de meta, rho da meta anterior deve estar perto de 6 cm.
    for lab, tr in zip(labels, trs):
        bad = tr[tr["completo"] & (tr["rho_final"] > GOAL_RADIUS + 0.03)]
        if len(bad):
            print("AVISO [%s]: %d troca(s) de meta com rho_final > %.2f m (goal_idx: %s)"
                  % (lab, len(bad), GOAL_RADIUS + 0.03, list(bad["goal_idx"])))

    plot_trajectories(data, trs, labels, args.outdir)
    plot_rho_alpha(data, trs, labels, args.outdir, "rho_alpha_goto")
    plot_rho_alpha(data, trs, labels, args.outdir, "rho_alpha_zoom_goto", tlim=args.zoom)

    table = pd.DataFrame({lab: metrics(tr) for lab, tr in zip(labels, trs)})
    table.to_csv(os.path.join(args.outdir, "metricas_goto.csv"), float_format="%.4f")
    allt = pd.concat([tr.assign(config=lab) for lab, tr in zip(labels, trs)], ignore_index=True)
    allt.to_csv(os.path.join(args.outdir, "trechos_goto.csv"), index=False, float_format="%.4f")

    print(table.to_string(float_format=lambda v: "%.4f" % v))
    print("\nFiguras e tabelas salvas em:", os.path.abspath(args.outdir))


if __name__ == "__main__":
    main()
